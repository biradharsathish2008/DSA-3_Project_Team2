package com.dsaproject;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

import com.dsaproject.algorithms.BestDealPriorityQueue;
import com.dsaproject.algorithms.EntityResolutionEngine;
import com.dsaproject.algorithms.ProductHashIndex;
import com.dsaproject.algorithms.ProductNormalizer;
import com.dsaproject.algorithms.ProductSorter;
import com.dsaproject.algorithms.StringSimilarity;
import com.dsaproject.algorithms.Trie;
import com.dsaproject.algorithms.UnionFind;
import com.dsaproject.model.ProductListing;

class CoreAlgorithmsTest {
    private ProductListing listing(String id,String name,String storage){return new ProductListing(id,"Amazon","Test",name,"Apple","iPhone 15","Smartphones","6GB",storage,"Black",68000,4.5,"In Stock");}
    @Test void normalizesUnits(){assertEquals("128gb",new ProductNormalizer().normalize("128 GB"));assertEquals("apple iphone 15 black 128gb",new ProductNormalizer().normalize("Apple iPhone 15 (Black, 128 GB)"));}
    @Test void trieSuggestsPrefixes(){Trie trie=new Trie();trie.insert("iPhone 15");trie.insert("iPhone 14");assertTrue(trie.startsWith("iph"));assertEquals(2,trie.getSuggestions("iph",8).size());}
    @Test void similarityAlgorithmsReturnExpectedValues(){var similarity=new StringSimilarity();assertEquals(1,similarity.levenshteinSimilarity("same","same"));assertTrue(similarity.jaccardSimilarity("apple iphone 15","apple iphone 15 black")>.7);}
    @Test void hashmapIndexFindsNormalizedNames(){var index=new ProductHashIndex(new ProductNormalizer());var product=listing("A","Apple iPhone 15 128GB Black","128GB");index.add(product);assertEquals("A",index.byId("A").getId());assertEquals(1,index.byName("APPLE iPhone 15 128 GB Black").size());}
    @Test void sorterOrdersPrices(){var first=listing("A","A","128GB");var second=listing("B","B","128GB");first.setPrice(70000);second.setPrice(60000);assertEquals("B",new ProductSorter().byPrice(List.of(first,second),true).get(0).getId());}
    @Test void entityResolutionSeparatesStorageVariants(){EntityResolutionEngine engine=new EntityResolutionEngine();var same=engine.compare(listing("A","Apple iPhone 15 128GB Black","128GB"),listing("B","Apple iPhone 15 (Black, 128 GB)","128 GB"));var different=engine.compare(listing("A","Apple iPhone 15 128GB Black","128GB"),listing("C","Apple iPhone 15 256GB Black","256GB"));assertEquals("SAME_PRODUCT",same.decision());assertNotEquals("SAME_PRODUCT",different.decision());}
    @Test void unionFindConnectsClusters(){UnionFind uf=new UnionFind(3);uf.union(0,1);assertEquals(uf.find(0),uf.find(1));assertNotEquals(uf.find(0),uf.find(2));}
    @Test void priorityQueueChoosesLowestPrice(){var queue=new BestDealPriorityQueue();var cheap=listing("A","A","128GB");var expensive=listing("B","B","128GB");expensive.setPrice(69000);var first=queue.bestDeal(List.of(cheap,expensive));assertEquals("A",first.getId());}
}
