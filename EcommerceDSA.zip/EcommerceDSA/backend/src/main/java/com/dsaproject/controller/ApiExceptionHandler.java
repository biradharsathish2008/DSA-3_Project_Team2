package com.dsaproject.controller;

import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(NoSuchElementException.class) ResponseEntity<?> notFound(Exception e){return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error","Resource not found"));}
    @ExceptionHandler({IllegalArgumentException.class, jakarta.validation.ConstraintViolationException.class}) ResponseEntity<?> badRequest(Exception e){return ResponseEntity.badRequest().body(Map.of("error","Invalid request"));}
    @ExceptionHandler(Exception.class) ResponseEntity<?> server(Exception e){return ResponseEntity.internalServerError().body(Map.of("error","Request could not be completed"));}
}
