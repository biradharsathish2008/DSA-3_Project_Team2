package com.dsaproject.algorithms;

import com.dsaproject.model.ProductListing;
import java.util.*;

public class ProductSorter {
    public List<ProductListing> byPrice(List<ProductListing> products, boolean ascending){var copy=new ArrayList<>(products); copy.sort(Comparator.comparingDouble(ProductListing::getPrice)); if(!ascending)Collections.reverse(copy); return copy;}
    public List<ProductListing> byRating(List<ProductListing> products){var copy=new ArrayList<>(products); copy.sort(Comparator.comparingDouble(ProductListing::getRating).reversed()); return copy;}
}
