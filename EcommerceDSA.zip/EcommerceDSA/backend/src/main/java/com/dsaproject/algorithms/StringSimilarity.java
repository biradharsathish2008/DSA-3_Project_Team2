package com.dsaproject.algorithms;

import java.util.*;

public class StringSimilarity {
    public double levenshteinSimilarity(String left, String right) {
        left = left == null ? "" : left.toLowerCase(); right = right == null ? "" : right.toLowerCase();
        int[] previous = new int[right.length()+1]; for (int j=0;j<=right.length();j++) previous[j]=j;
        for (int i=1;i<=left.length();i++) { int[] current=new int[right.length()+1]; current[0]=i; for (int j=1;j<=right.length();j++) current[j]=Math.min(Math.min(current[j-1]+1, previous[j]+1), previous[j-1]+(left.charAt(i-1)==right.charAt(j-1)?0:1)); previous=current; }
        int max=Math.max(left.length(), right.length()); return max==0 ? 1 : 1.0 - (double)previous[right.length()]/max;
    }
    public double jaccardSimilarity(String left, String right) {
        Set<String> a = new HashSet<>(Arrays.asList(left.toLowerCase().split("\\s+"))), b = new HashSet<>(Arrays.asList(right.toLowerCase().split("\\s+")));
        if (a.isEmpty() && b.isEmpty()) return 1; Set<String> intersection=new HashSet<>(a); intersection.retainAll(b); Set<String> union=new HashSet<>(a); union.addAll(b); return union.isEmpty()?0:(double)intersection.size()/union.size();
    }
}
