package com.dsaproject.algorithms;

import java.util.ArrayList;
import java.util.List;

import com.dsaproject.model.MatchResult;
import com.dsaproject.model.ProductAttributes;
import com.dsaproject.model.ProductListing;

public class EntityResolutionEngine {
    private final ProductNormalizer normalizer=new ProductNormalizer();
    private final StringSimilarity similarity=new StringSimilarity();
    public MatchResult compare(ProductListing a, ProductListing b){
        ProductAttributes x=normalizer.extract(a), y=normalizer.extract(b);
        boolean brand=eq(x.brand(),y.brand()), model=eq(x.model(),y.model()), category=eq(x.category(),y.category()), storage=eq(x.storage(),y.storage()), ram=eq(x.ram(),y.ram()), color=eq(x.color(),y.color());
        double title=similarity.levenshteinSimilarity(normalizer.normalize(a.getProductName()),normalizer.normalize(b.getProductName()));
        double score=100*(.20*bool(brand)+.30*bool(model)+.10*bool(category)+.15*bool(storage)+.10*bool(ram)+.05*bool(color)+.10*title);
        String decision=score>=90?"SAME_PRODUCT":score>=75?"POSSIBLE_MATCH":"DIFFERENT_PRODUCT";
        List<String> differences=new ArrayList<>(), explanation=new ArrayList<>();
        add(explanation,differences,brand,"Same brand","Brand differs"); add(explanation,differences,model,"Same model","Model differs"); add(explanation,differences,category,"Same category","Category differs"); add(explanation,differences,storage,"Same storage","Storage differs: "+x.storage()+" vs "+y.storage()); add(explanation,differences,ram,"Same RAM","RAM differs"); add(explanation,differences,color,"Same color","Color differs");
        explanation.add(title>=.85?"High title similarity":"Title similarity needs review");
        return new MatchResult(a.getId(),b.getId(),round(score),decision,new MatchResult.AttributeMatches(brand,model,category,storage,ram,color),round(title*100),differences,explanation);
    }
    private void add(List<String> good,List<String> bad,boolean match,String yes,String no){if(match)good.add(yes);else bad.add(no);}
    private boolean eq(String a,String b){return !a.isBlank()&&!b.isBlank()&&a.equals(b);} private double bool(boolean b){return b?1:0;} private double round(double n){return Math.round(n*10)/10.0;}
}
