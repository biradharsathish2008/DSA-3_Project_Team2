package com.dsaproject.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dsaproject.service.DashboardService;
import com.dsaproject.service.ProductService;

@RestController @RequestMapping("/api")
public class DashboardController {
    private final DashboardService service; private final ProductService products;
    public DashboardController(DashboardService s, ProductService p){service=s;products=p;}
    @GetMapping("/dashboard") public Object dashboard(){return service.dashboard();}
    @GetMapping("/analytics/matching") public Object matching(){return service.matchingAnalytics();}
    @GetMapping("/analytics/sellers") public Object sellers(){return service.sellers();}
    @GetMapping("/analytics/prices") public Object prices(){return service.prices();}
    @GetMapping("/dataset") public Object dataset(){return products.all();}
}
