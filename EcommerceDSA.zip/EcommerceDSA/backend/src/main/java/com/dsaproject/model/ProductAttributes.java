package com.dsaproject.model;

public record ProductAttributes(String brand, String model, String category, String ram, String storage, String color) {}
