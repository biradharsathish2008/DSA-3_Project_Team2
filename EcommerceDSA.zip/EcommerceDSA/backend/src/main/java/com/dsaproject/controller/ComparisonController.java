package com.dsaproject.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dsaproject.service.ProductService;

@RestController @RequestMapping("/api/comparison")
public class ComparisonController {
    private final ProductService products; public ComparisonController(ProductService p){products=p;}
    @GetMapping public Object compare(@RequestParam String first,@RequestParam String second){return List.of(products.one(first),products.one(second));}
}
