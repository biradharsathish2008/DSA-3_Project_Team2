package com.dsaproject.controller;

import com.dsaproject.model.ProductListing;
import com.dsaproject.service.ProductService;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/products") @Validated
public class ProductController {
    private final ProductService service; public ProductController(ProductService s){service=s;}
    @GetMapping public List<ProductListing> all(){return service.all();}
    @GetMapping("/{id}") public ProductListing one(@PathVariable @Size(min=2,max=20) String id){return service.one(id);}
    @GetMapping("/search") public List<ProductListing> search(@RequestParam(defaultValue="") @Size(max=80) String query){return service.search(query);}
    @GetMapping("/autocomplete") public List<String> autocomplete(@RequestParam(defaultValue="") @Size(max=80) String query){return service.autocomplete(query);}
    @GetMapping("/{id}/sellers") public List<ProductListing> sellers(@PathVariable String id){return service.sellers(id);}
}
