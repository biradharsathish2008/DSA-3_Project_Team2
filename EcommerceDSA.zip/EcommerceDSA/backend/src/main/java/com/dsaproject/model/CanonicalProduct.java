package com.dsaproject.model;

import java.util.List;

public record CanonicalProduct(String id, String name, String brand, String model, String category, String storage, String color, List<ProductListing> listings, double lowestPrice, double averagePrice, double confidence) {}
