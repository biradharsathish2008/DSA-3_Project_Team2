package com.dsaproject.model;

import java.util.List;

public record MatchResult(String listingA, String listingB, double confidenceScore, String decision, AttributeMatches attributes, double titleSimilarity, List<String> differences, List<String> explanation) {
    public record AttributeMatches(boolean brand, boolean model, boolean category, boolean storage, boolean ram, boolean color) {}
}
