package com.dsaproject.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dsaproject.service.MatchingService;

@RestController @RequestMapping("/api")
public class MatchingController {
    private final MatchingService service; public MatchingController(MatchingService s){service=s;}
    @PostMapping("/matching") public Object match(@RequestBody Map<String,String> body){return service.match(required(body,"listingA"),required(body,"listingB"));}
    @GetMapping("/matching/{id1}/{id2}") public Object match(@PathVariable String id1,@PathVariable String id2){return service.match(id1,id2);}
    @GetMapping("/duplicates") public Object duplicates(){return service.duplicates();}
    @GetMapping("/clusters") public Object clusters(){return service.clusters();}
    @GetMapping("/best-deal/{productId}") public Object deal(@PathVariable String productId){return service.bestDeal(productId);}
    private String required(Map<String,String> body,String key){String value=body.get(key);if(value==null||value.isBlank())throw new IllegalArgumentException(key+" is required");return value;}
}
