package com.dsaproject.algorithms;

import java.util.*;

public class Trie {
    private static class Node { Map<Character,Node> children=new TreeMap<>(); boolean word; String value; }
    private final Node root=new Node();
    public void insert(String value) { if (value==null || value.isBlank()) return; Node node=root; for(char c:value.toLowerCase().toCharArray()) node=node.children.computeIfAbsent(c,k->new Node()); node.word=true; node.value=value; }
    public boolean search(String value) { Node n=node(value); return n!=null && n.word; }
    public boolean startsWith(String prefix) { return node(prefix)!=null; }
    public List<String> getSuggestions(String prefix, int limit) { Node n=node(prefix); List<String> result=new ArrayList<>(); if(n!=null) collect(n,result,limit); return result; }
    private Node node(String text) { if(text==null)return null; Node n=root; for(char c:text.toLowerCase().toCharArray()){n=n.children.get(c); if(n==null)return null;} return n; }
    private void collect(Node n,List<String> result,int limit){if(result.size()>=limit)return; if(n.word)result.add(n.value); for(Node child:n.children.values())collect(child,result,limit);}
}
