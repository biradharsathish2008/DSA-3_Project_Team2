package com.dsaproject.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dsaproject.algorithms.EntityResolutionEngine;
import com.dsaproject.algorithms.ProductNormalizer;
import com.dsaproject.model.CanonicalProduct;
import com.dsaproject.model.ProductListing;
import com.dsaproject.service.ProductService;

@RestController @RequestMapping("/api/canonical-products")
public class CanonicalController {
    private final ProductService products; private final EntityResolutionEngine engine=new EntityResolutionEngine(); private final ProductNormalizer normalizer=new ProductNormalizer();
    public CanonicalController(ProductService products){this.products=products;}
    @GetMapping public List<CanonicalProduct> all(){Map<String,List<ProductListing>> groups=products.all().stream().collect(Collectors.groupingBy(p->normalizer.normalize(p.getBrand())+"|"+normalizer.normalize(p.getModel())+"|"+normalizer.normalize(p.getStorage())+"|"+normalizer.normalize(p.getColor()),LinkedHashMap::new,Collectors.toList()));int n=1;List<CanonicalProduct> result=new ArrayList<>();for(var e:groups.entrySet()){var p=e.getValue().get(0);double avg=e.getValue().stream().mapToDouble(ProductListing::getPrice).average().orElse(0);double min=e.getValue().stream().mapToDouble(ProductListing::getPrice).min().orElse(0);double confidence=e.getValue().size()<2?100:e.getValue().subList(1,e.getValue().size()).stream().mapToDouble(x->engine.compare(p,x).confidenceScore()).average().orElse(0);result.add(new CanonicalProduct(String.format("CP-%03d",n++),p.getBrand()+" "+p.getModel(),p.getBrand(),p.getModel(),p.getCategory(),p.getStorage(),p.getColor(),e.getValue(),min,avg,confidence));}return result;}
    @GetMapping("/{id}") public CanonicalProduct one(@PathVariable String id){return all().stream().filter(p->p.id().equalsIgnoreCase(id)).findFirst().orElseThrow();}
}
