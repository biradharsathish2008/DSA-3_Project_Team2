package com.dsaproject.repository;

import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Repository;

import com.dsaproject.model.ProductListing;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ProductRepository {
    private final List<ProductListing> products;
    public ProductRepository() {
        try (InputStream input=new ClassPathResource("data/products.json").getInputStream()) { products=new ObjectMapper().readValue(input,new TypeReference<>(){}); }
        catch(Exception e){ throw new IllegalStateException("Unable to load products.json",e); }
    }
    public List<ProductListing> findAll(){return List.copyOf(products);}
    public Optional<ProductListing> findById(String id){return products.stream().filter(p->p.getId().equalsIgnoreCase(id)).findFirst();}
}
