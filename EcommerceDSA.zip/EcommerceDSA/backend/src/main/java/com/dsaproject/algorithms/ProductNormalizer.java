package com.dsaproject.algorithms;

import com.dsaproject.model.ProductAttributes;
import com.dsaproject.model.ProductListing;
import java.util.Locale;

public class ProductNormalizer {
    public String normalize(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT).replaceAll("(?i)(\\d+)\\s*[- ]?gb", "$1gb").replaceAll("(?i)(\\d+)\\s*[- ]?tb", "$1tb").replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
    }
    public ProductAttributes extract(ProductListing p) {
        String name = normalize(p.getProductName());
        String storage = normalizeUnit(p.getStorage(), "gb");
        String ram = normalizeUnit(p.getRam(), "gb");
        if (storage.isBlank()) storage = findUnit(name, "gb|tb");
        if (ram.isBlank()) ram = findRam(name);
        String color = normalize(p.getColor());
        if (color.isBlank()) color = findColor(name);
        return new ProductAttributes(normalize(p.getBrand()), normalize(p.getModel()), normalize(p.getCategory()), ram, storage, color);
    }
    private String normalizeUnit(String value, String unit) { return value == null ? "" : normalize(value).replace(" ", ""); }
    private String findUnit(String value, String units) { var m = java.util.regex.Pattern.compile("(\\d+)\\s*(gb|tb)").matcher(value); return m.find() ? m.group(1)+m.group(2) : ""; }
    private String findRam(String value) { var m = java.util.regex.Pattern.compile("(\\d+)\\s*gb\\s*ram").matcher(value); return m.find() ? m.group(1)+"gb" : ""; }
    private String findColor(String value) { for (String c : new String[]{"black","white","blue","green","silver","gold","grey","gray","pink"}) if (value.contains(c)) return c; return ""; }
}
