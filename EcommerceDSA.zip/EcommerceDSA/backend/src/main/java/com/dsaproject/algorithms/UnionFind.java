package com.dsaproject.algorithms;

import java.util.*;

public class UnionFind {
    private final int[] parent, size;
    public UnionFind(int count){parent=new int[count]; size=new int[count]; for(int i=0;i<count;i++){parent[i]=i;size[i]=1;}}
    public int find(int value){if(parent[value]!=value)parent[value]=find(parent[value]);return parent[value];}
    public void union(int first,int second){int a=find(first),b=find(second);if(a==b)return;if(size[a]<size[b]){int t=a;a=b;b=t;}parent[b]=a;size[a]+=size[b];}
}
