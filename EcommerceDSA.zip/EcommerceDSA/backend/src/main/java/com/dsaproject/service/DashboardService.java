package com.dsaproject.service;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.dsaproject.model.ProductListing;
import com.dsaproject.model.Seller;

@Service
public class DashboardService {
    private final ProductService products; private final MatchingService matching;
    public DashboardService(ProductService p,MatchingService m){products=p;matching=m;}
    public Map<String,Object> dashboard(){var all=products.all();var clusters=matching.clusters();double confidence=0;int comparisons=0;for(var cluster:clusters){for(int i=1;i<cluster.size();i++){confidence+=matching.match(cluster.get(0),cluster.get(i)).confidenceScore();comparisons++;}}Map<String,Long> markets=all.stream().collect(Collectors.groupingBy(ProductListing::getMarketplace,TreeMap::new,Collectors.counting()));return new LinkedHashMap<>(Map.of("totalListings",all.size(),"canonicalProducts",clusters.size(),"duplicateListings",all.size()-clusters.size(),"averageMatchConfidence",comparisons==0?0:Math.round(confidence/comparisons*10)/10.0,"sellers",markets.size(),"productClusters",clusters.size(),"marketplaceDistribution",markets));}
    public Map<String,Object> matchingAnalytics(){var all=products.all();int same=0,possible=0,different=0;double total=0;for(int i=0;i<all.size();i++)for(int j=i+1;j<all.size();j++){var m=matching.match(all.get(i).getId(),all.get(j).getId());total+=m.confidenceScore();switch(m.decision()){case "SAME_PRODUCT"->same++;case "POSSIBLE_MATCH"->possible++;default->different++;}}int count=same+possible+different;return Map.of("totalMatches",count,"sameProducts",same,"possibleMatches",possible,"differentProducts",different,"averageMatchScore",count==0?0:Math.round(total/count*10)/10.0);}
    public List<Seller> sellers(){return products.all().stream().collect(Collectors.groupingBy(ProductListing::getMarketplace)).entrySet().stream().map(e->new Seller(e.getKey(),e.getValue().size(),e.getValue().stream().mapToDouble(ProductListing::getPrice).average().orElse(0),e.getValue().stream().mapToDouble(ProductListing::getRating).average().orElse(0))).sorted(Comparator.comparing(Seller::marketplace)).toList();}
    public Map<String,Double> prices(){var p=products.all().stream().mapToDouble(ProductListing::getPrice).summaryStatistics();return Map.of("lowestPrice",p.getMin(),"highestPrice",p.getMax(),"averagePrice",p.getAverage());}
}
