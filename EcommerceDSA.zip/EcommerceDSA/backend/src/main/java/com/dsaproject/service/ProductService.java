package com.dsaproject.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.dsaproject.algorithms.ProductHashIndex;
import com.dsaproject.algorithms.ProductNormalizer;
import com.dsaproject.algorithms.Trie;
import com.dsaproject.model.ProductListing;
import com.dsaproject.repository.ProductRepository;

@Service
public class ProductService {
    private final ProductRepository repository; private final ProductNormalizer normalizer=new ProductNormalizer(); private final Trie trie=new Trie(); private final ProductHashIndex index=new ProductHashIndex(normalizer);
    public ProductService(ProductRepository repository){this.repository=repository; repository.findAll().forEach(p->{trie.insert(p.getProductName());index.add(p);});}
    public List<ProductListing> all(){return repository.findAll();}
    public ProductListing one(String id){return repository.findById(id).orElseThrow(()->new NoSuchElementException("Product not found"));}
    public List<ProductListing> search(String query){String q=normalizer.normalize(query); if(q.isBlank())return all(); return all().stream().filter(p->normalizer.normalize(p.getProductName()).contains(q)||normalizer.normalize(p.getBrand()).contains(q)||normalizer.normalize(p.getModel()).contains(q)).collect(Collectors.toList());}
    public List<String> autocomplete(String query){return trie.getSuggestions(query,8);}
    public List<ProductListing> sellers(String id){ProductListing selected=one(id);String key=normalizer.normalize(selected.getBrand())+"|"+normalizer.normalize(selected.getModel())+"|"+normalizer.normalize(selected.getStorage())+"|"+normalizer.normalize(selected.getColor());return all().stream().filter(p->key.equals(normalizer.normalize(p.getBrand())+"|"+normalizer.normalize(p.getModel())+"|"+normalizer.normalize(p.getStorage())+"|"+normalizer.normalize(p.getColor()))).toList();}
    public ProductHashIndex index(){return index;}
}
