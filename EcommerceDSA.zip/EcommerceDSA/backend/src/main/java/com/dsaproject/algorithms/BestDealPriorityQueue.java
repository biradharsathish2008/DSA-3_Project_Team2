package com.dsaproject.algorithms;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import com.dsaproject.model.ProductListing;

public class BestDealPriorityQueue {
    public ProductListing bestDeal(List<ProductListing> listings){
        PriorityQueue<ProductListing> queue=new PriorityQueue<>(Comparator.comparingDouble(ProductListing::getPrice).thenComparing(Comparator.comparingDouble(ProductListing::getRating).reversed()));
        queue.addAll(listings); return queue.poll();
    }
}
