package com.dsaproject.model;

public class ProductListing {
    private String id, marketplace, seller, productName, brand, model, category, ram, storage, color;
    private double price, rating;
    private String availability = "In Stock";

    public ProductListing() {}
    public ProductListing(String id, String marketplace, String seller, String productName, String brand, String model, String category, String ram, String storage, String color, double price, double rating, String availability) {
        this.id=id; this.marketplace=marketplace; this.seller=seller; this.productName=productName; this.brand=brand; this.model=model; this.category=category; this.ram=ram; this.storage=storage; this.color=color; this.price=price; this.rating=rating; this.availability=availability;
    }
    public String getId(){return id;} public void setId(String v){id=v;}
    public String getMarketplace(){return marketplace;} public void setMarketplace(String v){marketplace=v;}
    public String getSeller(){return seller;} public void setSeller(String v){seller=v;}
    public String getProductName(){return productName;} public void setProductName(String v){productName=v;}
    public String getBrand(){return brand;} public void setBrand(String v){brand=v;}
    public String getModel(){return model;} public void setModel(String v){model=v;}
    public String getCategory(){return category;} public void setCategory(String v){category=v;}
    public String getRam(){return ram;} public void setRam(String v){ram=v;}
    public String getStorage(){return storage;} public void setStorage(String v){storage=v;}
    public String getColor(){return color;} public void setColor(String v){color=v;}
    public double getPrice(){return price;} public void setPrice(double v){price=v;}
    public double getRating(){return rating;} public void setRating(double v){rating=v;}
    public String getAvailability(){return availability;} public void setAvailability(String v){availability=v;}
}
