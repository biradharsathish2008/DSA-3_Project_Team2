package com.dsaproject.model;

public record Seller(String marketplace, long listings, double averagePrice, double averageRating) {}
