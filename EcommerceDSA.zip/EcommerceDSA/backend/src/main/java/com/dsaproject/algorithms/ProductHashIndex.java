package com.dsaproject.algorithms;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dsaproject.model.ProductListing;

public class ProductHashIndex {
    private final Map<String,ProductListing> byId=new HashMap<>();
    private final Map<String,List<ProductListing>> byName=new HashMap<>(), byBrand=new HashMap<>(), byModel=new HashMap<>();
    private final ProductNormalizer normalizer;
    public ProductHashIndex(ProductNormalizer normalizer){this.normalizer=normalizer;}
    public void add(ProductListing p){byId.put(p.getId(),p); add(byName,normalizer.normalize(p.getProductName()),p); add(byBrand,normalizer.normalize(p.getBrand()),p); add(byModel,normalizer.normalize(p.getModel()),p);}
    private void add(Map<String,List<ProductListing>> map,String key,ProductListing p){map.computeIfAbsent(key,k->new ArrayList<>()).add(p);}
    public ProductListing byId(String id){return byId.get(id);} public List<ProductListing> byName(String name){return byName.getOrDefault(normalizer.normalize(name),List.of());} public Collection<ProductListing> all(){return byId.values();}
}
