package com.dsaproject.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.dsaproject.algorithms.BestDealPriorityQueue;
import com.dsaproject.algorithms.EntityResolutionEngine;
import com.dsaproject.algorithms.UnionFind;
import com.dsaproject.model.MatchResult;
import com.dsaproject.model.ProductListing;

@Service
public class MatchingService {
    private final ProductService products; private final EntityResolutionEngine engine=new EntityResolutionEngine(); private final BestDealPriorityQueue deals=new BestDealPriorityQueue();
    public MatchingService(ProductService products){this.products=products;}
    public MatchResult match(String a,String b){return engine.compare(products.one(a),products.one(b));}
    public ProductListing bestDeal(String id){return deals.bestDeal(products.sellers(id));}
    public List<Map<String,Object>> duplicates(){List<ProductListing> all=products.all();List<Map<String,Object>> result=new ArrayList<>();for(int i=0;i<all.size();i++)for(int j=i+1;j<all.size();j++){MatchResult m=engine.compare(all.get(i),all.get(j));if(m.decision().equals("SAME_PRODUCT")){result.add(Map.of("listingA",all.get(i),"listingB",all.get(j),"match",m));}}return result;}
    public List<List<String>> clusters(){List<ProductListing> all=products.all();UnionFind uf=new UnionFind(all.size());for(int i=0;i<all.size();i++)for(int j=i+1;j<all.size();j++)if(engine.compare(all.get(i),all.get(j)).decision().equals("SAME_PRODUCT"))uf.union(i,j);Map<Integer,List<String>> groups=new LinkedHashMap<>();for(int i=0;i<all.size();i++)groups.computeIfAbsent(uf.find(i),k->new ArrayList<>()).add(all.get(i).getId());return new ArrayList<>(groups.values());}
    public EntityResolutionEngine engine(){return engine;}
}
