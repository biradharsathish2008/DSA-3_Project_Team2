async function renderPriceComparisonPage(){
  title.textContent='Price Comparison';
  loading('Loading product prices...');
  try{
    const rows=await get('/products');
    app.innerHTML=`<div class="card match-panel"><div class="section-head"><div><h2>Compare two product prices</h2><p>Select two listings to compare their current marketplace prices.</p></div></div><div class="match-layout"><label>Product A<select id="price-a" class="select full">${rows.map(p=>`<option value="${p.id}">${esc(p.productName)} · ${esc(p.marketplace)}</option>`).join('')}</select></label><label>Product B<select id="price-b" class="select full">${rows.map((p,i)=>`<option value="${p.id}" ${i===1?'selected':''}>${esc(p.productName)} · ${esc(p.marketplace)}</option>`).join('')}</select></label></div><button id="price-run" class="button full-button">Compare prices</button></div><div id="price-output" class="price-compare-grid" style="margin-top:18px"><div class="empty-state">Choose two products to compare.</div></div>`;
    document.querySelector('#price-run').onclick=()=>{
      const a=rows.find(p=>p.id===document.querySelector('#price-a').value);const b=rows.find(p=>p.id===document.querySelector('#price-b').value);const difference=Math.abs(a.price-b.price);const lower=a.price<=b.price?a:b;
      document.querySelector('#price-output').innerHTML=`<div class="card product-card price-compare-card"><span class="badge">Product A</span><h3>${esc(a.productName)}</h3><p>${esc(a.marketplace)} · ${esc(a.seller)}</p><div class="price">${money(a.price)}</div><p>Rating: ★ ${a.rating}</p></div><div class="card product-card price-compare-card"><span class="badge">Product B</span><h3>${esc(b.productName)}</h3><p>${esc(b.marketplace)} · ${esc(b.seller)}</p><div class="price">${money(b.price)}</div><p>Rating: ★ ${b.rating}</p></div><div class="card price-winner"><span class="badge green">Lower price</span><h2>${money(lower.price)}</h2><p>${esc(lower.productName)} is lower by <strong>${money(difference)}</strong>.</p></div>`;
    };
  }catch(e){fail()}
}
document.querySelector('.nav-item[data-page="prices"]').addEventListener('click',renderPriceComparisonPage);
