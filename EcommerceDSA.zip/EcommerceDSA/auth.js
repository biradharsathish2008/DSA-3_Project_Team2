const AUTH_KEY = 'er_demo_session';
const ACCOUNTS_KEY = 'er_demo_accounts';
const authScreen = document.createElement('section');

authScreen.className = 'auth-screen';
authScreen.innerHTML = `<div class="auth-panel">
  <div class="auth-brand"><div class="auth-mark">ER</div><div><strong>E-Commerce Product</strong><span>Entity Resolution</span></div></div>
  <div id="login-view">
    <h1>Welcome back</h1>
    <form id="login-form">
      <label class="auth-field" for="login-email">Email address</label>
      <input class="auth-input" id="login-email" type="email" placeholder="you@example.com" autocomplete="email" required>
      <label class="auth-field" for="login-password">Password</label>
      <input class="auth-input" id="login-password" type="password" placeholder="Enter your password" autocomplete="current-password" minlength="4" required>
      <p class="auth-error" id="auth-error"></p>
      <div class="login-role" role="group" aria-label="Login type">
        <button class="role-button active" id="customer-login" type="button">Customer Login</button>
        <button class="role-button" id="admin-login" type="button">Admin Login</button>
      </div>
      <input type="hidden" id="login-role" value="customer">
      <button class="auth-submit" type="submit">Sign in to dashboard</button>
    </form>
    <div class="auth-demo">Demo access: enter any valid email and a password with at least 4 characters.</div>
    <p class="auth-switch">New here? <button class="auth-link" id="show-signup" type="button">Create a new account</button></p>
  </div>
  <div id="signup-view" hidden>
    <h1>Create your account</h1>
    <p class="auth-subtitle">Set up an account to access your product intelligence dashboard.</p>
    <form id="signup-form">
      <label class="auth-field" for="signup-name">Full name</label>
      <input class="auth-input" id="signup-name" type="text" placeholder="Your name" autocomplete="name" required>
      <label class="auth-field" for="signup-email">Email address</label>
      <input class="auth-input" id="signup-email" type="email" placeholder="you@example.com" autocomplete="email" required>
      <label class="auth-field" for="signup-password">Password</label>
      <input class="auth-input" id="signup-password" type="password" placeholder="At least 4 characters" autocomplete="new-password" minlength="4" required>
      <label class="auth-field" for="signup-confirm-password">Confirm password</label>
      <input class="auth-input" id="signup-confirm-password" type="password" placeholder="Re-enter your password" autocomplete="new-password" minlength="4" required>
      <p class="auth-error" id="signup-error"></p>
      <button class="auth-submit" type="submit">Create account</button>
    </form>
    <p class="auth-switch">Already have an account? <button class="auth-link" id="show-login" type="button">Sign in</button></p>
  </div>
  <p class="auth-note">Product Intelligence Platform · DSA-3</p>
</div>`;

document.body.classList.add('auth-locked');
document.body.insertBefore(authScreen, document.body.firstChild);

function unlock() {
  document.body.classList.remove('auth-locked');
  authScreen.remove();
  sessionStorage.setItem(AUTH_KEY, 'active');
  setNavigation(sessionStorage.getItem('er_login_role') || 'customer');
}

function lock() {
  sessionStorage.removeItem(AUTH_KEY);
  sessionStorage.removeItem('er_login_role');
  document.body.classList.add('auth-locked');
  document.body.insertBefore(authScreen, document.body.firstChild);
  document.querySelector('#login-form').reset();
  document.querySelector('#login-view').hidden = false;
  document.querySelector('#signup-view').hidden = true;
  setNavigation('customer');
}

function setNavigation(role) {
  const customerNavigation = document.querySelector('#customer-navigation');
  const adminNavigation = document.querySelector('#admin-navigation');
  if (!customerNavigation || !adminNavigation) return;
  const isAdmin = role === 'admin';
  customerNavigation.hidden = isAdmin;
  adminNavigation.hidden = !isAdmin;
}

document.querySelector('#logout-button').addEventListener('click', () => {
  lock();
});

if (sessionStorage.getItem(AUTH_KEY) === 'active') {
  setNavigation(sessionStorage.getItem('er_login_role') || 'customer');
  unlock();
} else {
  const loginView = document.querySelector('#login-view');
  const signupView = document.querySelector('#signup-view');
  const showLogin = () => {
    loginView.hidden = false;
    signupView.hidden = true;
  };
  const showSignup = () => {
    loginView.hidden = true;
    signupView.hidden = false;
    document.querySelector('#signup-name').focus();
  };

  document.querySelector('#show-signup').addEventListener('click', showSignup);
  document.querySelector('#show-login').addEventListener('click', showLogin);
  document.querySelector('#customer-login').addEventListener('click', () => setLoginRole('customer'));
  document.querySelector('#admin-login').addEventListener('click', () => setLoginRole('admin'));

  function setLoginRole(role) {
    document.querySelector('#login-role').value = role;
    document.querySelector('#customer-login').classList.toggle('active', role === 'customer');
    document.querySelector('#admin-login').classList.toggle('active', role === 'admin');
    document.querySelector('.auth-submit').textContent = role === 'admin' ? 'Sign in as admin' : 'Sign in to dashboard';
  }

  document.querySelector('#login-form').addEventListener('submit', event => {
    event.preventDefault();
    const email = document.querySelector('#login-email').value.trim();
    const password = document.querySelector('#login-password').value;
    const role = document.querySelector('#login-role').value;
    const error = document.querySelector('#auth-error');
    if (!email || !email.includes('@')) {
      error.textContent = 'Enter a valid email address.';
      return;
    }
    if (password.length < 4) {
      error.textContent = 'Password must contain at least 4 characters.';
      return;
    }
    error.textContent = '';
    sessionStorage.setItem('er_login_role', role);
    unlock();
    if (role === 'admin') {
      setTimeout(() => navigate('admin'), 0);
    }
  });

  document.querySelector('#signup-form').addEventListener('submit', event => {
    event.preventDefault();
    const name = document.querySelector('#signup-name').value.trim();
    const email = document.querySelector('#signup-email').value.trim().toLowerCase();
    const password = document.querySelector('#signup-password').value;
    const confirmPassword = document.querySelector('#signup-confirm-password').value;
    const error = document.querySelector('#signup-error');
    const accounts = JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || '[]');

    if (!name) {
      error.textContent = 'Enter your name.';
      return;
    }
    if (!email || !email.includes('@')) {
      error.textContent = 'Enter a valid email address.';
      return;
    }
    if (password.length < 4) {
      error.textContent = 'Password must contain at least 4 characters.';
      return;
    }
    if (password !== confirmPassword) {
      error.textContent = 'Passwords do not match.';
      return;
    }
    if (accounts.some(account => account.email === email)) {
      error.textContent = 'An account with this email already exists.';
      return;
    }

    accounts.push({ name, email, password, role: 'customer' });
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
    document.querySelector('#login-email').value = email;
    document.querySelector('#signup-form').reset();
    showLogin();
    document.querySelector('#auth-error').textContent = 'Account created. You can now sign in.';
  });
}
