# E-Commerce Product Entity-Resolution & Matching Platform

A DSA-3 project that identifies the same real-world product across marketplace listings, resolves listings into canonical products, detects duplicates, and compares seller prices.

## Architecture

`index.html` + `styles.css` + `app.js` provide a responsive vanilla frontend. The frontend calls a Java Spring Boot REST API. The backend loads `backend/src/main/resources/data/products.json` through a repository abstraction, then applies algorithms in the service layer.

## DSA implementation

- **HashMap:** `ProductHashIndex` indexes IDs, normalized names, brands, and models with average O(1) lookup.
- **Trie:** `Trie` powers `/api/products/autocomplete` with O(L) prefix traversal.
- **String matching:** `StringSimilarity` implements Levenshtein similarity in O(m*n) and Jaccard token similarity.
- **Entity resolution:** `EntityResolutionEngine` compares normalized attributes and weighted title similarity. Weights are brand 20%, model 30%, category 10%, storage 15%, RAM 10%, color 5%, title 10%.
- **Union-Find:** `MatchingService` unions pairs classified `SAME_PRODUCT` using path compression and union by size.
- **PriorityQueue:** `BestDealPriorityQueue` ranks lowest price first and rating second.
- **Sorting:** `ProductSorter` ranks by price or rating.

Scores at or above 90% are `SAME_PRODUCT`; 75-89% are `POSSIBLE_MATCH`; lower scores are `DIFFERENT_PRODUCT`. Storage and RAM differences therefore prevent identical grouping even when titles are very similar.

## Project structure

```text
backend/
  pom.xml
  src/main/java/com/dsaproject/
    algorithms/      DSA implementations
    controller/      REST endpoints
    model/           API/domain models
    repository/      JSON data source
    service/         application orchestration
  src/main/resources/data/products.json
index.html
styles.css
app.js
README.md
```

## REST API

`GET /api/products`, `/api/products/{id}`, `/api/products/search?query=`, `/api/products/autocomplete?query=`, `/api/products/{id}/sellers`, `/api/matching/{id1}/{id2}`, `POST /api/matching`, `/api/duplicates`, `/api/clusters`, `/api/best-deal/{productId}`, `/api/canonical-products`, `/api/canonical-products/{id}`, `/api/comparison?first=&second=`, `/api/dashboard`, `/api/analytics/matching`, `/api/analytics/sellers`, `/api/analytics/prices`, `/api/dataset`.

## Run on Windows

Install JDK 17 and Maven, then from the project root:

```powershell
cd backend
mvn spring-boot:run
```

The API runs at `http://localhost:8080`. Open `index.html` with VS Code Live Server. The frontend expects the API at `http://localhost:8080/api`.

## Dataset and testing

The initial dataset contains 50 listings across Amazon, Flipkart, Croma, Reliance Digital, and Myntra. It includes intentional title variations for shared products and an iPhone 15 128GB/256GB false-match case. Maven tests can be added under `backend/src/test/java`; the algorithm classes are isolated and ready for unit testing.

No MySQL, payment, checkout, authentication, or shopping-cart features are required. A database can be introduced later behind `ProductRepository`.
