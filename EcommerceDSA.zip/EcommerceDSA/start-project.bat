@echo off
cd /d "%~dp0"

start "Backend" powershell -NoExit -Command "cd '%~dp0backend'; mvn spring-boot:run"
start "Frontend" powershell -NoExit -Command "cd '%~dp0'; py -m http.server 5500"

start http://localhost:5500
