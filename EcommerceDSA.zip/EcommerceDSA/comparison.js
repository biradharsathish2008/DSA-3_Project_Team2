async function renderComparisonPage(){
  title.textContent='Product Comparison';
  loading('Loading comparison catalog...');
  try{
    const rows=await get('/products');
    app.innerHTML=`<div class="card match-panel"><div class="section-head"><div><h2>Compare product listings</h2><p>Compare factual attributes and marketplace prices without subjective claims.</p></div></div><div class="match-layout"><label>Product A<select id="compare-a" class="select full">${rows.map(p=>`<option value="${p.id}">${esc(p.productName)}</option>`).join('')}</select></label><label>Product B<select id="compare-b" class="select full">${rows.map((p,i)=>`<option value="${p.id}" ${i===1?'selected':''}>${esc(p.productName)}</option>`).join('')}</select></label></div><button id="compare-run" class="button full-button">Compare products</button></div><div id="compare-output" class="card" style="margin-top:18px"><div class="empty-state">Choose two records to compare.</div></div>`;
    document.querySelector('#compare-run').onclick=async()=>{
      const output=document.querySelector('#compare-output');output.innerHTML='<div class="loading-state">Comparing product attributes...</div>';
      try{const data=await get(`/comparison?first=${document.querySelector('#compare-a').value}&second=${document.querySelector('#compare-b').value}`);const a=data[0],b=data[1];const fields=[['Brand','brand'],['Model','model'],['Category','category'],['RAM','ram'],['Storage','storage'],['Color','color'],['Price','price'],['Rating','rating']];output.innerHTML=`<div class="table-wrap"><table class="table"><thead><tr><th>Attribute</th><th>${esc(a.productName)}</th><th>${esc(b.productName)}</th></tr></thead><tbody>${fields.map(([label,key])=>`<tr><td><strong>${label}</strong></td><td>${key==='price'?money(a[key]):esc(a[key])}</td><td>${key==='price'?money(b[key]):esc(b[key])}</td></tr>`).join('')}</tbody></table></div>`}catch(e){output.innerHTML='<div class="empty-state">No comparison available for these records.</div>'}
    };
  }catch(e){fail()}
}
document.querySelector('.nav-item[data-page="comparison"]').addEventListener('click',renderComparisonPage);
